#ifndef __GLOBAL_VARAIBLE__H_
#define __GLOBAL_VARAIBLE__H_
#include "SimType.h"
// case for int variable 
/*************************************************************************
*              Model Parameter											 *
*************************************************************************/
extern __device__ void  * modelInputSet; 
extern __device__ void  * modelOuputSet; 
extern __device__ void  * modelStateSet; 

/*************************************************************************
*              Model Parameter											 *
*************************************************************************/

/*************************************************************************
*              TIme Parameter											 *
*************************************************************************/
extern __device__ TIME  * m_tN; 
extern __device__ TIME  * m_tL; 

extern __device__ TIME  * NextTN ; 
extern __device__ TIME  * NextLocalTN ; 

/*************************************************************************
*              Messsage  Parameter										 *
*************************************************************************/
extern __device__ UINT * bSendYMsg; 
extern __device__ PORTINFO	*	DestGloPortInfo; 

/*************************************************************************
*              Log Debugging  Parameter									 *
*************************************************************************/
extern __device__ void * DebugMem;			//Debugging  information 

#endif
