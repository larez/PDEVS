/********************************************************************
*  sample.cu
*  This is a example of the CUDA program.
*********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "cuda_runtime.h"
#include "device_launch_parameters.h"


#include "SimType.h"
#include "Forest.h"
#include "time.h"
#include <string.h>

/************************************************************************/
/* Init CUDA                                                            */
/************************************************************************/
extern "C" int	AddComponent ( unsigned int argNumModel , unsigned int argRow, unsigned int argCol ) ;
extern "C" int	SimulationStart() ; 
extern "C" void DeallocateDeviceVar () ;
extern "C" int	SetDeviceInitModel( InputSet * hInput , OutputSet * hOutput , 
								   ModelState * hState ,   int argnumModel , int argX, int argY ) ; 
extern "C" int testbench(  ); 


bool InitCUDA() 
{
    cudaError_t cudaStatus;

	// Choose which GPU to run on, change this on a multi-GPU system.
	cudaStatus = cudaSetDevice(0);
	if (cudaStatus != cudaSuccess) {
		fprintf(stderr, "cudaSetDevice failed!  Do you have a CUDA-capable GPU installed?");
		return false; 
	}

	return true;
}

//#endif
/************************************************************************/
/* HelloCUDA                                                            */
/************************************************************************/
void initialHostModelParam ( ModelState * hState , 
							int nArray ){ 
	for ( int i = 0 ; i < nArray ; ++i  ) { 
		hState[i].FireState = UNBURNED; 
		hState[i].fuel = 900 ; 
		hState[i].bulk = 300 ; 
		hState[i].heatSupplied = 0 ; 
		hState[i].windDegree = 0 ; 
	}
};

int main(int argc ,char ** argv) 
{
	if(!InitCUDA()) 
	{
		return 0;
	}
	char ch ; 

    // use command-line specified CUDA device, otherwise use device with highest Gflops/s
	AddComponent( FieldWidth * FieldHeight, FieldWidth , FieldHeight  ) ; 
	InputSet hostInput[FieldHeight * FieldWidth] ;	
	OutputSet hostOutput[FieldHeight * FieldWidth] ;	
	ModelState hostState[FieldHeight * FieldWidth] ;	

	// The model set initialization 
	memset ( hostInput , 0 , sizeof( InputSet)* FieldWidth * FieldHeight ) ; 
	memset ( hostOutput , 0 , sizeof( InputSet)* FieldWidth * FieldHeight ) ; 

	initialHostModelParam ( hostState, FieldWidth * FieldHeight  ) ; 
	hostState[261888].FireState = INITBURN; 

	SetDeviceInitModel ( hostInput , hostOutput , hostState  , FieldWidth * FieldHeight , BDX, BDY  ); 

	clock_t start = clock() ; 

	SimulationStart() ;

	//for ( int i = 0 ; i< 2240 ;++i ) { 
	//	testbench();
	//}

	printf("Time elapsed: %f\n", ((double)clock() - start) / CLOCKS_PER_SEC);

	DeallocateDeviceVar (); 

	ch = getchar() ; 
	
  // tracing tools such as Nsight and Visual Profiler to show complete traces.
    cudaError_t cudaStatus = cudaDeviceReset();
    if (cudaStatus != cudaSuccess) {
        fprintf(stderr, "cudaDeviceReset failed!");
        return 1;
    }
} 



