#ifndef __FOREST_MODEL_PARAMETER_H_
#define __FOREST_MODEL_PARAMETER_H_

#define DIR							8
// Area
#define Width						300 

// Wind effects
#define	WindAngle		 0.0  
#define Beta			 0.0719		// related to wind intensity 
#define MinHeatCoff		 0.4 

//heat fuels
extern __constant__ float			DiffW			= 20;			// Losing Weight : unit ( kg )  
extern __constant__ float			Hcoff			= 19000; 

#define DiffW			20			// Losing Weight : unit ( kg )  
#define Hcoff			19000

//Heat of preignition 
#define Alpha			200

//extern __constant__ float			Moist			= 0.5 ; 
//extern __constant__ float			Qig				= 250 + 1116 * Moist  ; 
//extern __constant__ float			Pb				= 200; 
//extern __constant__ float			Epsilon			= expf ( -138 / Alpha ); 
//extern __constant__ float			Pbe				= Pb * Epsilon ; 


#define  Moist			0.5  
#define	Qig				250 + 1116 * ( Moist )    
#define Pb				200 
#define Epsilon			expf ( -138 / Alpha )
#define Pbe				(Pb)  * ( Epsilon )   

//Grid length      

#endif