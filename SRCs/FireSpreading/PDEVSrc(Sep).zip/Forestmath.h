#ifndef __FOREST_MODEL_MATHEMATICAL_FUNCITON__
#define __FOREST_MODEL_MATHEMATICAL_FUNCITON__
#include "ForestParameter.h"
#include "Forest.h"

__device__ void getHeatIntensity( float * Intensity, float WindDegree, float generatedHeat ); 
__device__ void getOutputDelay( float * Delay , float * Intensity  ) ; 

__device__ void setNeighborAreaExist ( bool * isGlobalExist , bool * isLocalExist ); 
__device__ void getDiff	( DIRECTION * destDirect , int * diffy , int * diffx , int dir ) ; 

#endif 