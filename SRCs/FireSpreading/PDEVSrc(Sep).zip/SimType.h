#ifndef __MODEL_TYPE_H__
#define __MODEL_TYPE_H__

typedef unsigned int UINT  ; 
typedef float TIME ; 
typedef int  PORTINFO; 

#define	BLOCKSIZEX	16
#define	BLOCKSIZEY	16


#define BDX			32
#define BDY			32

#define 	FieldWidth	  512	//number of separated area in y 
#define 	FieldHeight   512	//number of separated area in x 

#define TBLOCKSIZEX 16
#define TBLOCKSIZEY 16

#define DUR 700
#define CORDUR 300

#define INF  4000000.0f
#define NonExist  -1 



#endif