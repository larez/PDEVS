========================================================================
    CUDA Windows APPLICATION : PDEVSim Project Overview
========================================================================

AppWizard has created this PDEVSim application for you.  

PDEVSim.vcproj
    This is the main project file for VC++ projects generated using an CUDA Windows Application Wizard. 
    It contains information about the version of Visual C++ and CUDA cu that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

sample.cu

    This is the cuda application source file.


/////////////////////////////////////////////////////////////////////////////
AppWizard has created the following resources:


/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" comments to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
