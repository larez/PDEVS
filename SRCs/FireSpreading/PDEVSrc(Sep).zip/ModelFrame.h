#ifndef __MODEL_FRAME_H_
#define __MODEL_FRAME_H_

struct ModelPos{ 
	int	x ;
	int y ; 
};

//Model State 
template <typename TIn, typename TOut, typename TState > struct ModelSet
{
	TIn		inputSet; 
	TOut	outputSet;  
	TState  stateSet ; 
};


// DEVS 4 function Runninsg in GPU 
// __device__ is appended 
/* 
template < class  TIn, class  TOut, class  TState > 
__device__  void IntTransFn( ModelSet <TIn , TOut ,TState>  * modelset ) ; 

template < class  TIn, class  TOut, class  TState > 
__device__  void ExtTransFn(ModelSet <TIn , TOut ,TState> * modelset )  ; 

template < class  TIn, class  TOut, class  TState > 
__device__  void OutputFn(ModelSet <TIn , TOut ,TState>  * modelset  ) ; 

template < class  TIn, class  TOut, class  TState > 
__device__  TIME TimeAdvanceFn(ModelSet <TIn , TOut ,TState>  * modelset) ; 

template < class  TIn, class  TOut, class  TState > 
__device__  bool ConfluentFn( ModelSet <TIn , TOut ,TState>  * modelset) ; 

template < class  TIn, class  TOut, class  TState > 
__device__  void InternalCoupRelation(ModelSet <TIn , TOut ,TState>  * modelset,
									  TIn  * LocalModelSet , UINT * bSendYMsg  ) ; 

*/

#endif