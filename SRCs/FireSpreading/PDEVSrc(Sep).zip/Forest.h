#ifndef __FOREST_MODEL_H_
#define __FOREST_MODEL_H_

#include "Glo.h"
#include "ForestParam.h"

#include "ModelFrame.h"

#define	  DT			10

// Forest input set 
struct InputSet { 
	float iPort[DIR]; 
};

// Forest output set 
struct OutputSet { 
	float oPort[DIR]; 
};

enum ForestState{ 
	UNBURNED, 
	BURNING,
	SPREADING, 
	BURNED, 
	INITBURN
}; 

struct ModelState{
	ForestState		FireState; 
	float 			fuel ; 
	float			bulk ;
	float			heatSupplied ;
	float			windDegree  ; 
	TIME			leftTime[DIR] ; 
	float			HeatIntensity[DIR] ; 
};

enum DIRECTION { 
	N = 0, 
	NE , 
	E , 
	SE,  
	S,
	SW, 
	W ,
	NW 
};

struct DebugType { 
	bool bWrite; 
	bool hist[5];	//0 Output function , 1 
	UINT ouputDestModel[DIR];  
	ForestState FiresState[5];  
};

enum FuncType { 
	OUTFUNC, 
	INTFUNC, 
	EXTFUNC, 
	CUNFUNC,
	TAFUNC
};


#endif 